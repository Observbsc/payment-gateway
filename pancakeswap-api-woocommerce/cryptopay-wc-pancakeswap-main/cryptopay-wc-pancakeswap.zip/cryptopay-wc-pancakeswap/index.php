<?php 

namespace BeycanPress\CryptoPay\WooCommerce;

/**
 * Plugin Name: CryptoPay WooCommerce PancakeSwap Converter API
 * Version:     1.0.0
 * Plugin URI:  https://beycanpress.com/
 * Description: Extra currency converter api for "Payment plugin with her cryptocurrency wallet for WooCommerce"
 * Author: BeycanPress
 * Author URI:  https://www.beycanpress.com
 * License:     GPLv3
 * License URI: https://www.gnu.org/licenses/gpl-3.0.tr.html
 * Tags: Cryptopay, Cryptocurrency, WooCommerce, WordPress, MetaMask, Trust, Binance, Wallet, Ethereum, Bitcoin, Binance smart chain, Payment, Plugin, Gateway
 * Requires at least: 5.0
 * Tested up to: 5.9
 * Requires PHP: 7.3
*/

require_once __DIR__ . '/vendor/autoload.php';

use CSF;
use Beycan\CurrencyConverter;

add_action('plugins_loaded', function() {

    if (class_exists(Loader::class)) {

        class PancakeSwap extends PluginHero\Plugin
        {
            public function __construct()
            {
                add_filter("CryptoPay/WooCommerce/Converters", function($converters) {
                    $converters['pancakeswap'] = 'PancakeSwap';
                    return $converters;
                });
            
                if ($this->setting('converterApi') == 'pancakeswap') {
                    add_filter(
                        "CryptoPay/WooCommerce/CurrencyConverter", 
                        function(
                            $paymentPrice, 
                            $selectedCurrency,
                            $orderCurrency, 
                            $orderPrice
                        ) 
                    {
                        try {
                            $converter = new CurrencyConverter('cryptocompare');
                        
                            $result = wp_remote_get('https://api.pancakeswap.info/api/v2/tokens/'.$selectedCurrency->address);
                            if (isset($result['response']) && $result['response']['code'] == 200) {
                                if ($tokenPrice = json_decode($result['body'])->data->price) {
                                    $orderUsdPrice = $converter->convert($orderCurrency, 'USD', $orderPrice);
                                    return (float) ($orderUsdPrice / $tokenPrice);
                                }
                            }

                            $paymentPrice = $converter->convert($orderCurrency, $selectedCurrency->symbol, $orderPrice);
                
                            if ($paymentPrice) return $paymentPrice;
                            
                            return null;
                        } catch (\Exception $e) {
                            return null;
                        }
                    }, 10, 4);
                }

            }
        }
        
        new PancakeSwap();
    }
});
